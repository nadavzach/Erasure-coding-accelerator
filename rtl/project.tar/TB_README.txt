test bench files

  - block level
  - full chip
